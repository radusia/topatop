Commerce Migrate Ubercart has moved to its own project:
http://drupal.org/project/commerce_migrate_ubercart.
